package connpackage;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class NotebookDb {
	    Connection con ;

	    public NotebookDb(Connection con) {
	        this.con = con;
	    }
	    
	    //for register user 
	    public boolean saveUser(Notebook nb){
	        boolean set = false;
	        try{
	            //Insert register data to database
	           String query = "insert into notes(name,data) values(?,?)";
	           
	           PreparedStatement pt = this.con.prepareStatement(query);
	           pt.setString(1,nb.getName());
	           pt.setString(2,nb.getData());
	           
	           
	           pt.executeUpdate();
	           set = true;
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	        return set;
	    }
	    public boolean Add(Notebook nb){
	        boolean set = false;
	        try{
	            //Insert register data to database
	        	String query = "update notes set data=? where id=?";
	        	 PreparedStatement pt = this.con.prepareStatement(query);
	        	 pt.setString(1, nb.getData());
		         
		           
	          
	           
	           pt.executeUpdate();
	           set = true;
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	        return set;
}
}