package connpackage;

import java.sql.*;


public class ConnectionPro {
    private static Connection con;
    
    public static Connection getConnection(){
        try{
        	String url="jdbc:mysql://localhost:3306/jsp_project";
   		 Class.forName("com.mysql.cj.jdbc.Driver");

   		 con = DriverManager.getConnection(url,"root","Divya@99");
   		
        }catch(Exception e){
            e.printStackTrace();
        }
        return con;
    }
}
