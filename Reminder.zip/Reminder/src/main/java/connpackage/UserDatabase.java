package connpackage;
	import java.sql.*;


	public class UserDatabase{
	    Connection con ;

	    public UserDatabase(Connection con) {
	        this.con = con;
	    }
	    
	    //for register user 
	    public boolean saveUser(User user){
	        boolean set = false;
	        try{
	            //Insert register data to database
	           String query = "insert into sign(name,email,phone,password) values(?,?,?,?)";
	           
	           PreparedStatement pt = this.con.prepareStatement(query);
	           pt.setString(1, user.getName());
	           pt.setString(2, user.getEmail());
	           pt.setString(3, user.getPhone());
	           pt.setString(4, user.getPassword());
	           
	           pt.executeUpdate();
	           set = true;
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	        return set;
	    }
	  //user login
	    public User logUser(String email, String pass){
	        User usr=null;
	        try{
	            String query ="select * from sign where email=? and password=?";
	            PreparedStatement pst = this.con.prepareStatement(query);
	            pst.setString(1, email);
	            pst.setString(2, pass);
	            
	            ResultSet rs = pst.executeQuery();
	            
	            if(rs.next())
	            {
	                usr = new User(email,pass);
	                usr.setId(rs.getInt("id"));
	                usr.setName(rs.getString("name"));   
	            }  
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }
	        return usr;
	    }
	    
	    //edit user
	    public boolean editUser(User user){
	        boolean set = false;
	        try{
	            //Insert register data to database
	        	String query = "update sign set name=?,email=?,phone=?,password=? where id=?";
	        	 PreparedStatement pt = this.con.prepareStatement(query);
		           pt.setString(1, user.getName());
		           pt.setString(2, user.getEmail());
		           pt.setString(3, user.getPhone());
		           pt.setString(4, user.getPassword());
		           pt.setInt(5, user.getId());
	          
	           
	           pt.executeUpdate();
	           set = true;
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	        return set;
	    }
	    public ResultSet getres(String tablename) {
	    	ResultSet rs=null;
	            try{
	               String query ="select * from "+ tablename;
	               Statement st = this.con.createStatement();
	               
	               rs = st.executeQuery(query);
	               
	                
	            }catch(Exception e){
	                e.printStackTrace();
	            }
	            return rs;
	        }
	    	
	    }

