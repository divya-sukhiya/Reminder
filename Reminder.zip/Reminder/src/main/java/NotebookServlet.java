import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import connpackage.ConnectionPro;
import connpackage.Notebook;
import connpackage.NotebookDb;


/**
 * Servlet implementation class NotebookServlet

 */
@WebServlet("/NotebookServlet")
public class NotebookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NotebookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//PrintWriter out=response.getWriter();
		
		String name = request.getParameter("name");
		String data = request.getParameter("data");
		Notebook nb = new Notebook(name,data);

		//create a database model
		NotebookDb regNotebook = new NotebookDb(ConnectionPro.getConnection());
		if ( regNotebook.saveUser(nb)) {
		HttpSession session = request.getSession();
		 session.setAttribute("id", nb.getId());
		   response.sendRedirect("AddNewNotebook.jsp");
		} else {
		    String errorMessage = "User Available";
		    HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("Reminder.jsp");
		    }

	}

}
