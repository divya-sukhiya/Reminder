package Dao;
import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import connpackage.*;
public class UserDao {
	
	private static final String insert_notes =  "insert into notes where name=?";
	private static final String delete_notes =  "delete from notebooks where id=?";
	private static final String selectAll = "select name,data from notes";
	private static final String edit_user =  "update sign set name=?,email=?,phone=?,password=?";
	private static final String insert_notebook = "insert into notes(name,data) values(?,?)";
	
	protected Connection getConnection(){
        Connection con = null;
		try{
         String url="jdbc:mysql://localhost:3306/jsp_project";
   		 Class.forName("com.mysql.cj.jdbc.Driver");

   		 con = DriverManager.getConnection(url,"root","Divya@99");
   		
        }catch(Exception e){
      e.printStackTrace();
        }
        return con;
    }
	
	
	//insert notes
	public void insertNotes(Notes n)
	{
		try(Connection con = getConnection();
		PreparedStatement st = con.prepareStatement(insert_notes))
		{
				st.setString(1,n.getData());
				st.executeUpdate();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	//selectall notes
	public ArrayList<Notes> selectAllNotes()
	{
		ArrayList<Notes> nt = new ArrayList<>();
		try(Connection con = getConnection();
				PreparedStatement st = con.prepareStatement(selectAll);)
		{
			ResultSet rs = st.executeQuery();
			while(rs.next())
			{
			
				String name = rs.getString("name");
				String data = rs.getString("data");
				nt.add(new Notes(name,data));
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	return nt;
	}
	
	//delete notes
	public boolean Delete_Notes(int id) throws SQLException
	{
		boolean rdelete = false;
		try(Connection con = getConnection();
				PreparedStatement st = con.prepareStatement(delete_notes);)
		{
			st.setInt(1,id);
			rdelete = st.executeUpdate() >0 ;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return rdelete;	
	}
	//edit user
	public boolean EditUser(User user)
	{
		boolean b = false;
		try(Connection con = getConnection();
				PreparedStatement st = con.prepareStatement(edit_user);)
		{
			st.setString(1,user.getName());
			st.setString(2,user.getEmail());
			st.setString(3,user.getPhone());
			st.setString(4,user.getPassword());
			b = st.executeUpdate(edit_user) > 0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return b;
	}
	//edit notes
	
	public void insert_Notebook(Notes n)
	{
		try(Connection con = getConnection();
				PreparedStatement st = con.prepareStatement(insert_notebook))
		{
			st.setString(1,n.getName());
			st.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
}
