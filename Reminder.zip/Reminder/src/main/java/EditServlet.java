

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import connpackage.ConnectionPro;
import connpackage.User;
import connpackage.UserDatabase;

/**
 * Servlet implementation class EditServlet
 */
@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//PrintWriter out=response.getWriter();
    	 HttpSession session = request.getSession();
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String phone=request.getParameter("phone");
		String password = request.getParameter("password");
		int id=(int)session.getAttribute("id");
		User userModel = new User(id,name, email, phone,password);

		//create a database model
		UserDatabase regUser = new UserDatabase(ConnectionPro.getConnection());
		if (regUser.editUser(userModel)) {
		   response.sendRedirect("Reminder.jsp");
		} else {
		String errorMessage = "User Available";
		HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("Reminder.jsp");
		    }

	}	
}